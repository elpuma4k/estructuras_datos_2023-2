#include<iostream>
#include "lista.h"

int main(){
  Lista l1;
  l1.anxLista(11);
  l1.anxLista(3);
  l1.anxLista(8);

  return 0;
}
